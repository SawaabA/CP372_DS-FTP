# Video Script (Very Simple)

Use this exactly while recording.

## 1) Open terminals

- Terminal A = Receiver
- Terminal B = Sender

In both terminals:

```powershell
cd C:\Users\Sawaa\Documents\CP372-NETOWRKS-2\CP372_DS-FTP
```

Compile once:

Terminal A:
```powershell
cd Receiver
javac *.java
```

Terminal B:
```powershell
cd Sender
javac *.java
```

## 2) Intro line (read this)

"This is our CP372 Assignment 2 DS-FTP demo. We will show Stop-and-Wait, Go-Back-N, ACK loss recovery, and file correctness."

## 3) Demo 1: Stop-and-Wait, no loss

Terminal A:
```powershell
java Receiver 127.0.0.1 51011 52011 ..\out_video_sw.txt 0
```

Terminal B:
```powershell
java Sender 127.0.0.1 52011 51011 ..\sample_small.txt 300
```

What to say when logs appear:

- `SOT recv seq=0` -> "Receiver got start of transmission."
- `ACK send seq=0` -> "Receiver confirmed start with ACK 0."
- `SEND DATA seq=1` -> "Sender is sending first data packet."
- `DATA write seq=1` -> "Receiver wrote packet 1 to output file."
- `SEND EOT seq=...` -> "Sender is ending the transfer."
- `Receiver done.` -> "Transfer closed cleanly."

## 4) Demo 2: GBN with ACK loss

Terminal A:
```powershell
$env:DSFTP_WINDOW="40"
java Receiver 127.0.0.1 51012 52012 ..\out_video_gbn.txt 5
```

Terminal B:
```powershell
java Sender 127.0.0.1 52012 51012 ..\sample_big.txt 300 40
```

What to say when logs appear:

- `ACK drop seq=...` -> "Loss simulation is active. Every 5th ACK is dropped."
- `GBN SEND seq=...` -> "Sender is sending many packets in a window."
- `GBN ACK accepted...` -> "Sender got cumulative ACK and moved window forward."
- `GBN timeout...` -> "Timeout happened, sender retransmitted from base."
- Final success lines -> "GBN still completed successfully under ACK loss."

## 5) Hash check (prove output is correct)

Go to project root and run:

```powershell
cd ..
Get-FileHash .\sample_small.txt
Get-FileHash .\out_video_sw.txt
Get-FileHash .\sample_big.txt
Get-FileHash .\out_video_gbn.txt
```

Say:
"Matching hashes mean the output files are exactly the same as input files."

## 6) Close line (read this)

"This demo showed correct start and end control packets, reliable transfer, loss recovery, and verified output integrity."

## 7) 10-second cheat sheet (if nervous)

- `SOT` = start packet
- `ACK` = confirmation packet
- `DATA write` = receiver saved packet to file
- `EOT` = end packet
- `timeout` = expected during loss, sender retransmits

## 8) Quick fixes if something breaks

- File not found: check path (`..\sample_small.txt` or `..\sample_big.txt`)
- Receiver stuck: press `Ctrl + C` and rerun receiver
- Port busy: use new port pair in both commands (example: `51021` + `52021`)
